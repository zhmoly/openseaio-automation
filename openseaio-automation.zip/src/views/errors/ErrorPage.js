import React from 'react';
import PageLayout from '../../layouts/PageLayout';

const ErrorPage = () => {

  return (
    <PageLayout>

      <h4>
        Not Found
      </h4>

    </PageLayout>
  );
};

export default ErrorPage;

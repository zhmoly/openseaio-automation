module.exports = global.config = {
    API_URL: 'http://127.0.0.1:8000/api',
    // API_URL: 'http://miadev.17s.network/channel/public/api'
};